import { Link } from "react-router";
import HeartIcon from "../Products/HeartIcon";

const Product = ({ product }) => {
  return (
    <div className="w-[30rem] ml-[2rem] p-3 relative transition duration-300 hover:scale-[1.015]">
      <div className="relative overflow-hidden rounded-lg shadow-md bg-[#1a1a1a] hover:shadow-xl transition-all duration-300">
        <img
          src={`http://localhost:5000${product.image}`}
          alt={product.name}
          className="min-w-[30rem] max-w-[28rem] min-h-[17rem] max-h-[20rem] object-cover rounded-t-lg"
        />
        <HeartIcon product={product} />

        <div className="p-4">
          <Link to={`/product/${product._id}`}>
            <h2 className="flex justify-between items-center mb-2">
              <span className="text-white font-medium text-base truncate max-w-[18rem]">
                {product.name}
              </span>
              <span className="bg-pink-100 text-pink-800 text-sm font-semibold px-2.5 py-0.5 rounded-full dark:bg-pink-900 dark:text-pink-300">
                ${product.price}
              </span>
            </h2>
          </Link>
          <p className="text-gray-400 text-sm line-clamp-2">
            {product.description?.substring(0, 100)}...
          </p>
        </div>
      </div>
    </div>
  );
};

export default Product;
