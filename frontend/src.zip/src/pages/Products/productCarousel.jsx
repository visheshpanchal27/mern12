import { useGetTopProductsQuery } from "../../redux/api/productApiSlice";
import Message from "../../components/Massage";
import Slider from "react-slick";
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import moment from "moment";
import {
  FaBox,
  FaClock,
  FaShoppingCart,
  FaStar,
  FaStore,
} from "react-icons/fa";

const ProductCarousel = () => {
  const { data: products, isLoading, error } = useGetTopProductsQuery();

  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
    autoplay: true,
    autoplaySpeed: 3000,
  };

  return (
    <div className="mb-8 px-4 xl:px-0">
      {isLoading ? null : error ? (
        <Message variant="danger">
          {error?.data?.message || error.message}
        </Message>
      ) : (
        <Slider {...settings} className="max-w-7xl mx-auto">
          {products.map(
            ({
              image,
              _id,
              name,
              price,
              description,
              brand,
              createdAt,
              numReviews,
              rating,
              quantity,
              countInStock,
            }) => (
              <div key={_id} className="relative">
                <img
                  src={`http://localhost:5000${image}`}
                  alt={name}
                  className="w-full h-[28rem] object-cover rounded-xl shadow-lg"
                />

                {/* Overlay Card */}
                <div className="absolute top-10 left-10 right-10 bg-[#0f0f0f]/80 backdrop-blur-md p-6 rounded-xl text-white shadow-xl flex flex-col md:flex-row justify-between gap-6">
                  {/* Left Block */}
                  <div className="md:w-2/3">
                    <h2 className="text-2xl font-semibold text-pink-400 mb-2">{name}</h2>
                    <p className="text-lg text-pink-300 font-medium mb-4">$ {price}</p>
                    <p className="text-gray-300 mb-4">
                      {description.substring(0, 160)}...
                    </p>
                  </div>

                  {/* Right Info */}
                  <div className="flex flex-wrap gap-6 text-sm text-gray-300 md:w-1/3">
                    <div>
                      <div className="flex items-center mb-2">
                        <FaStore className="mr-2 text-pink-400" />
                        <span>Brand: {brand}</span>
                      </div>
                      <div className="flex items-center mb-2">
                        <FaClock className="mr-2 text-yellow-400" />
                        <span>Added: {moment(createdAt).fromNow()}</span>
                      </div>
                      <div className="flex items-center mb-2">
                        <FaStar className="mr-2 text-green-400" />
                        <span>Reviews: {numReviews}</span>
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center mb-2">
                        <FaStar className="mr-2 text-yellow-300" />
                        <span>Rating: {Math.round(rating)}</span>
                      </div>
                      <div className="flex items-center mb-2">
                        <FaShoppingCart className="mr-2 text-blue-400" />
                        <span>Quantity: {quantity}</span>
                      </div>
                      <div className="flex items-center mb-2">
                        <FaBox className="mr-2 text-purple-400" />
                        <span>In Stock: {countInStock}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )
          )}
        </Slider>
      )}
    </div>
  );
};

export default ProductCarousel;
