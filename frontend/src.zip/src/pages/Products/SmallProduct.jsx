import { Link } from "react-router-dom";
import HeartIcon from "../Products/HeartIcon";

const SmallProduct = ({ product }) => {
  return (
    <div className="w-full max-w-xs sm:max-w-sm p-4 bg-[#1a1a1a]/60 backdrop-blur-md rounded-xl shadow-lg transition-transform transform hover:scale-105 duration-300">
      <div className="relative">
        <img
          src={`http://localhost:5000${product.image}`}
          alt={product.name}
          className="h-40 w-full object-cover rounded-lg shadow-inner"
        />
        <HeartIcon product={product} />
      </div>

      <div className="mt-4">
        <Link to={`/product/${product._id}`}>
          <h2 className="text-white text-base font-semibold hover:text-pink-500 transition duration-200">
            {product.name}
          </h2>
        </Link>
        <div className="mt-2 flex justify-between items-center">
          <span className="text-sm text-gray-400">Price</span>
          <span className="text-sm font-semibold text-pink-400 bg-pink-800/20 px-3 py-1 rounded-full shadow-sm">
            ${product.price}
          </span>
        </div>
      </div>
    </div>
  );
};

export default SmallProduct;
