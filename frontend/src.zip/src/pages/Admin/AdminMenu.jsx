import { useState } from "react";
import { NavLink } from "react-router-dom";
import { FaTimes } from "react-icons/fa";

const AdminMenu = () => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    const toggleMenu = () => {
        setIsMenuOpen(!isMenuOpen);
    }

    return (
    <div>
      <button type="button" className={`${isMenuOpen? "top-3 right-3" : "top-5 right-7"} bg-[#151515] p-2 fixed rounded-lg`} onClick={toggleMenu}>
        {isMenuOpen ? (
            <FaTimes color="white" />
        ):(
            <>
                <div className="w-6 h-0.5 bg-gray-200 my-1"></div>
                <div className="w-6 h-0.5 bg-gray-200 my-1"></div>
                <div className="w-6 h-0.5 bg-gray-200 my-1"></div>
            </>
        )}
      </button>

        {isMenuOpen && (
            <section className="bg-[#151515] p-4 fixed right-9 top-7">
                <ul className="flex flex-col gap-4">
                    <NavLink
                        to="/admin/dashboard"
                        end
                        className="list-item py-2 px-3 block mb-5 hover:bg-[#2E2D2D] rounded-sm"
                        style={({ isActive }) => ({
                            color: isActive ? "greenyellow" : "white",
                          })}
                          
                    >
                        Admin Dashboard
                    </NavLink>

                    <li>
                        <NavLink
                            className="list-item py-2 px-3 block mb-5 hover:bg-[#2E2D2D] rounded-sm"
                            to="/admin/categoryList"
                            style={({ isActive }) => ({
                            color: isActive ? "greenyellow" : "white",
                            })}
                        >
                            Create CategoryList
                        </NavLink>
                    </li>
                    <li>
                        <NavLink
                            className="list-item py-2 px-3 block mb-5 hover:bg-[#2E2D2D] rounded-sm"
                            to="/admin/productList"
                            style={({ isActive }) => ({
                            color: isActive ? "greenyellow" : "white",
                            })}
                        >
                            Create Product
                        </NavLink>
                    </li>
                    <li>
                        <NavLink
                            className="list-item py-2 px-3 block mb-5 hover:bg-[#2E2D2D] rounded-sm"
                            to="/admin/allProductsList"
                            style={({ isActive }) => ({
                            color: isActive ? "greenyellow" : "white",
                            })}
                        >
                            All Products
                        </NavLink>
                    </li>
                    <li>
                        <NavLink
                            className="list-item py-2 px-3 block mb-5 hover:bg-[#2E2D2D] rounded-sm"
                            to="/admin/userlist"
                            style={({ isActive }) => ({
                            color: isActive ? "greenyellow" : "white",
                            })}
                        >
                            Manage Users
                        </NavLink>
                    </li>
                    <li>
                        <NavLink
                            className="list-item py-2 px-3 block mb-5 hover:bg-[#2E2D2D] rounded-sm"
                            to="/admin/orderlist"
                            style={({ isActive }) => ({
                            color: isActive ? "greenyellow" : "white",
                            })}
                        >
                            Manage Orders
                        </NavLink>
                    </li>
                </ul>
            </section>
        )}

    </div>
  )
}
export default AdminMenu
